# -*- coding: UTF-8 -*-
"""PyBank Homework Starter File."""

# Dependencies
import budget_data.csv
import os

# Files to load and output (update with correct file paths)
file_to_load = os.path.join("Resources", "PyBank.csv")  # Input file path
file_to_output = os.path.join("analysis", "PyBank.txt")  # Output file path

# Define variables to track the financial data
total_months = 0
total_profit_losses = 0
previous_profit = None
profit_losses_changes = []
greatest_increase = ["", 0]
greatest_decrease = ["", float('inf')]

# Open and read the csv
with open(file_to_load) as budget_data:
    reader = csv.reader(budget_data)

    # Skip the header row
    header = next(reader)

    # Process each row of data
    for row in reader:
        date = row[0]
        profit_losses = int(row[1])

        # Track the total months and profit/losses
        total_months += 1
        total_profit_losses += profit_losses

        # Track the net change
        if previous_profit is not None:
            change = profit_losses - previous_profit
            profit_losses_changes.append(change)

            # Calculate the greatest increase in profits (month and amount)
            if change > greatest_increase[1]:
                greatest_increase = [date, change]

            # Calculate the greatest decrease in losses (month and amount)
            if change < greatest_decrease[1]:
                greatest_decrease = [date, change]

        previous_profit = profit_losses

# Calculate the average net change across the months
average_change = sum(profit_losses_changes) / len(profit_losses_changes) if profit_losses_changes else 0

# Generate the output summary
output_summary = f"""
Financial Analysis
----------------------------
Total Months: {total_months}
Total: ${total_profit_losses:,.2f}
Average Change: ${average_change:,.2f}
Greatest Increase in Profits: {greatest_increase[0]} (${greatest_increase[1]:,.2f})
Greatest Decrease in Profits: {greatest_decrease[0]} (${greatest_decrease[1]:,.2f})
"""

# Print the output
print(output_summary)

# Write the results to a text file
with open(file_to_output, 'w') as textfile:
    textfile.write(output_summary)
